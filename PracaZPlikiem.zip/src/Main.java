import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.nio.charset.Charset;

public class Main {
    public static void main(String[] args) {
       if (args.length > 0) {
            odczytLiczbowy(args);
        } else {
            System.out.println("Podaj sciezki!");
        }
        //dniOdUr();
    }


    public static void dniOdUr() {
        System.out.println("Podaj date urodzenia(yyyy-MM-dd): ");
        Scanner sc = new Scanner(System.in);
        String dataStr = sc.nextLine();
        LocalDate data = LocalDate.parse(dataStr);
        Period period = Period.between(data, LocalDate.now());
        System.out.println(period);
        long dni = ChronoUnit.DAYS.between(data, LocalDate.now());
        System.out.println(dni);
        int intelekt = (int)(dni % 33);
        if(intelekt <= 15) {
            System.out.println("biorytm +");
        }
        else {
            System.out.println("biorytm -");
        }
    }

    public static void plik(String[] args) {
       Path filePath = Paths.get(args[0]);
       try {
           List<String> lines = Files.readAllLines(filePath);
           lines.forEach(System.out::println);
       }
       catch (IOException e) {
           throw new RuntimeException();
       }
    }

    private static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static void odczytLiczbowy(String[] args) {
        if (args.length != 2) {
            System.out.println("Nalezy podac dwa pliki tesktowe");
            return;
        }

        Path inputPath = Paths.get(args[0]);
        Path outputPath = Paths.get(args[1]);

        try {
            List<String> lines = Files.readAllLines(inputPath);

            List<String> numbers = lines.stream()
                    .filter(Main::isNumeric)
                    .collect(Collectors.toList());

            Files.write(outputPath, numbers);

            System.out.println("Zapis przebiegl pomyslnie");

        } catch (IOException e) {
            System.err.println("Wystapil blad podczas odczytu: " + e.getMessage());
        }
    }

    public static void konwersja(String[] args) {
        if (args.length != 2) {
            System.out.println("Podaj sciezki do dwoch plikow");
            return;
        }

        String inputFilePath = args[0];
        String outputFilePath = args[1];

        try {
            Path inputPath = Paths.get(inputFilePath);
            List<String> lines = Files.readAllLines(inputPath, Charset.forName("windows-1250"));

            Path outputPath = Paths.get(outputFilePath);
            Files.write(outputPath, lines, Charset.forName("UTF-8"));

            System.out.println("Konwersja zakonczona pomyslnie!");
        } catch (IOException e) {
            System.err.println("Wystapil blad: " + e.getMessage());
        }
    }
    public static void merge(String[] args) {
        if (args.length < 2) {
            System.out.println("Podaj sciezki do dwoch plikow!");
            return;
        }

        String outputFilePath = args[args.length - 1];
        Path outputPath = Paths.get(outputFilePath);

        try {
            Files.createFile(outputPath);
            for (int i = 0; i < args.length - 1; i++) {
                String inputFilePath = args[i];
                Path inputPath = Paths.get(inputFilePath);

                List<String> lines = Files.readAllLines(inputPath);
                Files.write(outputPath, lines, java.nio.file.StandardOpenOption.APPEND);
            }

            System.out.println("Pliki polaczone pomyslnie w pliku: " + outputFilePath);

        } catch (IOException e) {
            System.err.println("Wystapil blad: " + e.getMessage());
        }
    }
}