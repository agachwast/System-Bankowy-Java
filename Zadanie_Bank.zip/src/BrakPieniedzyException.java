public class BrakPieniedzyException extends Exception {
    public BrakPieniedzyException(String message) { super(message); }
}
