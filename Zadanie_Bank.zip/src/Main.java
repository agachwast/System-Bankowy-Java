public class Main {
    public static void main(String[] args) {
        Wlasciciel w = new Wlasciciel("Klaudia", "Polinska", "20-223", "Kielce");
        Wlasciciel w2 = new Wlasciciel("Natalia", "Makowa", "20-223", "Kielce");

        Konto konto = new Konto(w);
        Konto konto2 = new Konto(w2);

        konto.Wplac(300);
        konto2.Wplac(500);


        Bank bank1 = new Bank("allemamona");
        bank1.utworzKonto(konto);
        bank1.utworzKonto(konto2);

        Lokata l = new Lokata(w, Lokata.OkresEnum.roczna, 3);
        bank1.utworzKonto(l);
        System.out.println(bank1.toString());
    }
}