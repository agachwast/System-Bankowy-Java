import java.util.ArrayList;

public class Bank {

    //region GiS
    public ArrayList<Konto> getKonta() {
        return konta;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }
    //endregion

    ArrayList<Konto> konta;
    public String nazwa;

    public Bank(String nazwa) {
        setNazwa(nazwa);
        this.konta = new ArrayList<>();
    }

    public void utworzKonto(Konto k) {
        this.konta.add(k);
    }
    public void usunKonto(long nrKonta) {
        for(Konto k : konta) {
            if(k.getNrKonta() == nrKonta) {
                konta.remove(k);
                System.out.println("usunieto!");
            }
        }
    }
    public Konto podajKonto(long nrKonta) {
        for(Konto k : konta) {
            if(k.getNrKonta() == nrKonta) {
                return k;
            }
        }
        return null;
    }

    public Konto podajKonto(String nazwa) {
        for(Konto k : konta) {
            if(k.getWlasc().equals(nazwa)) {
                return k;
            }
        }
        return null;
    }

    public double saldoBanku() {
        double saldo = 0;
        for(Konto k : konta) {
            saldo += k.getStanKonta();
        }
        return saldo;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for(Konto k : konta) {
            sb.append(k.toString()).append("\n");
        }
        sb.append("Saldo Banku: " + saldoBanku());
        return sb.toString();
    }
}
