import java.text.NumberFormat;
import java.util.Locale;

public class Lokata extends Konto{

    public enum OkresEnum {
        roczna,
        polroczna,
        trzymiesieczna
    }
    float oprocentowanie;
    static long biezacynrLokaty = 200;

    OkresEnum okres;
    public Lokata(Wlasciciel wlasc, OkresEnum okres, float oprocentowanie) {
        super(wlasc);
        this.okres = okres;
        this.oprocentowanie = oprocentowanie;
        biezacynrLokaty++;

    }

    @Override
    public String toString() {
        NumberFormat formatZl = NumberFormat.getCurrencyInstance(new Locale("pl", "PL"));
        return "Lokata nr " + getNrKonta() + ": " + getWlasc() + ", okres: " + okres + ", oprocentowanie: "
                + oprocentowanie + "%, stan: " + formatZl.format(getStanKonta());
    }
}
