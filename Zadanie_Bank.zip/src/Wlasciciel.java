public class Wlasciciel {
    private String nazwa;
    private String ulica;
    private String kod;
    private String miejscowosc;

    public String GetNazwa() {
        return nazwa;
    }
    public void SetNazwa(String nazwa) {
        if(nazwa.length() < 3) {
            throw new IllegalArgumentException();
        }
        else{
            this.nazwa = nazwa;
        }
    }
    public String GetUlica() {
        return ulica;
    }
    public void SetUlica(String ulica) {
        if(ulica.length() < 3) {
            throw new IllegalArgumentException();
        }
        else{
            this.ulica = ulica;
        }
    }
    public String GetKod() {
        return kod;
    }
    public void SetKod(String kod) {
        if(kod.matches("\\d{2}-\\d{3}")) {
            this.kod = kod;
        }
        else {
            throw new IllegalArgumentException();
        }
    }
    public String GetMiejscowosc() {
        return miejscowosc;
    }
    public void SetMiejscowosc(String miejscowosc) {
        if(miejscowosc.length() < 3) {
            throw new IllegalArgumentException();
        }
        else{
            this.miejscowosc = miejscowosc;
        }
    }

    public Wlasciciel(String nazwa, String ulica, String kod, String miejscowosc) {
        SetNazwa(nazwa);
        SetUlica(ulica);
        SetKod(kod);
        SetMiejscowosc(miejscowosc);
    }

    @Override
    public String toString() {
        return GetNazwa();
    }
}
