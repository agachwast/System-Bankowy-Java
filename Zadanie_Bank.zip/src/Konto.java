import java.text.NumberFormat;
import java.util.Locale;

public class Konto {
    private Wlasciciel wlasc;
    private double stanKonta;

    private long nrKonta;
    static long biezacynrKonta = 100;

    //region settery i gettery
    public Wlasciciel getWlasc() {
        return wlasc;
    }
    public double getStanKonta() {
        return stanKonta;
    }
    public long getNrKonta() {
        return nrKonta;
    }
    public void setWlasc(Wlasciciel wlasc) {
        this.wlasc = wlasc;
    }
    public void setStanKonta(double stanKonta) {
        this.stanKonta = stanKonta;
    }
    public void setNrKonta(long nrKonta) {
        this.nrKonta = nrKonta;
    }
    //endregion

    public Konto() {}
    public Konto(Wlasciciel wlasc) {
        setWlasc(wlasc);
        biezacynrKonta++;
        setNrKonta(biezacynrKonta);
        setStanKonta(0);
    }

    @Override
    public String toString() {
        NumberFormat formatZl = NumberFormat.getCurrencyInstance(new Locale("pl", "PL"));
        return getNrKonta() + ": " + getWlasc() + ", stan: " + formatZl.format(getStanKonta());
    }

    public void Wplac(double wplata) {
        this.stanKonta += wplata;
    }
    public boolean MoznaWyplacic(double wyplata) {
        if(wyplata > getStanKonta()) {
            return false;
        }
        else {
            return true;
        }
    }

    public void Wyplac(double wyplata) throws BrakPieniedzyException {
        if(MoznaWyplacic(wyplata)) {
            this.stanKonta -= wyplata;
        }
        else {
            throw new BrakPieniedzyException("Brak srodkow");
        }
    }

    static void Przelej(Konto k1, Konto k2, double kwota) throws BrakPieniedzyException {
        if(k1.MoznaWyplacic(kwota)) {
            k1.Wyplac(kwota);
            k2.Wplac(kwota);
        }
        else {
            throw new BrakPieniedzyException("Brak srodkow");
        }

    }
}
